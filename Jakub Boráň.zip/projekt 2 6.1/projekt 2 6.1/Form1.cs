﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt_2_6._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool down, up;
        private void zmacknout(object sender, KeyEventArgs e)
        {
            panel2.BackColor = Color.White;
            if (e.KeyCode == Keys.Up) {
                up = true;
            }
     
            if (e.KeyCode == Keys.Down)
            {
                down = true;
            }
            if(down == true)
            {
                panel2.BackColor = Color.Red;
            }
            if (up == true)
            {
                panel2.BackColor = Color.Green;
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void nezmacknuto(object sender, KeyEventArgs e)
        {
            panel2.BackColor = System.Drawing.Color.White; ;

            down = false;
            up = false;
        }

    
    }
}
